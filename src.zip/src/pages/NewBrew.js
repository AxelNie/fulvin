import '../App.css';
import React, { useState } from "react";
import EnterInfo1 from '../components/EnterInfo1'
import EnterInfo2 from '../components/EnterInfo2'
import EnterInfo3 from '../components/EnterInfo3'


function NewBrew({onNewBrew}) {
    const [activeStep, setActiveStep] = useState(1);
    const [brew, setBrew] = useState({name:5, date:null});


    function stepOneCompleted(input){
        setActiveStep(2);
        setBrew({...brew,name:input})
        onNewBrew(brew);
    }
    const myDate = new Date();
    console.log(myDate.toISOString());
    const myOtherDate = new Date(myDate.toISOString());
    console.log(myOtherDate)
    return (
      <div class="Wrapper">
          {activeStep === 1 && <EnterInfo1 onInput={stepOneCompleted}/>}
          {activeStep === 2 &&<EnterInfo2/>}
          {activeStep === 3 &&<EnterInfo3/>}
        
      </div>
  
    );
  }
  
  export default NewBrew;