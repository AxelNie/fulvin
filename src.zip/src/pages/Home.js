import React from "react";
import './Home.css';
import App from '../App';

function Home({brewList})  {
  
console.log(brewList);

  return (
  

    <div>
    <div class="info">
      <div class= "top">

      </div>
      <div class="middle">
        
  <div class="vänster"> <p class="övertext"> {} </p> 
        <p class="undertext"> Beräknat slutdatum </p></div> 
      
        <div class="mitten">  </div>

        <div class="höger"> <p class="övertext"> 6 Dagar </p> <p class="undertext"> till nästa uppgift </p> </div>
      </div>

      <div class="bottom">

        <div class="vänster"> <p class="övertext"> {} </p> 
        <p class="undertext"> Satser </p> </div>

        <div class="mitten"> <p class="övertext"> 6.2% </p> 
        <p class="undertext"> Alkohol </p> </div>


        <div class="höger"> <p class="övertext"> {} </p> 
        <p class="undertext"> Liter totalt </p> </div>
      </div>
    </div>
    

    <div id="fulvinsnamn">
    <p id="fulvinsnamn_text"> Fulvin </p>
    </div>

    <div id="kommande"> <p id="kommande_text"> Kommande uppgifter </p>
    </div>

    <div id="uppgift"> <p id="datum" > 15 Oktober </p> 
    <p id="uppgift_text" > blablabla </p>



    </div>

    </div>
  );
}

export default Home;
