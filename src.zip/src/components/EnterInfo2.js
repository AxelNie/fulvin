import '../App.css';
import React from "react";
import Button from './Button';
import LandingPage from './LandingPage';
import addBrew from  '../addBrew';
import EnterInfo1 from './EnterInfo1';


import {
  BrowserRouter as Router,
  Switch,
  Route,
  useParams,
  Link,
  useHistory,
  withRouter
} from "react-router-dom";

var history = 0;
var brewDate;

class NameForm1 extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = {value: ''};

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    
    
  }
  

  handleChange(event) {
    this.setState({value: event.target.value});
    
  }

  handleSubmit(event) {
  
    brewDate = this.state.value;
    
 
    history.push("/3", {brewDate});
//console.log(window.brewList[0].name);

    event.preventDefault();
  }

  render() {
    

    
    
    return (
     <form onSubmit={this.handleSubmit}>
        <label>
          iDate:
          <input type="text" onChange={this.handleChange} />
        </label>
        
        <input type="submit" value="Submit" />
        
      </form>
    );
  }
}


const EnterInfo2 = () => {
 
 history = useHistory();
 

  return (
    
    <div className="LandingPage"> 
        <header>
          <h1>ENTERinfo2</h1>
        </header>
        <NameForm1/>
        
    </div>
    
  );
}

export default EnterInfo2;