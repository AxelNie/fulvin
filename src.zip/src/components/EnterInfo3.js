import '../App.css';
import React from "react";
import Button from './Button';
import LandingPage from './LandingPage';
import addBrew from '../addBrew';
import EnterInfo1 from './EnterInfo1';
import EnterInfo2 from './EnterInfo2';


import {
    BrowserRouter as Router,
    Switch,
    Route,
    useParams,
    Link,
    useHistory,
    withRouter
} from "react-router-dom";

var history = 0;

const EnterInfo3 = () => {
    //console.log(brewDate);
    //addBrew(brewName, brewDate, "20/20/20");

    return (
        <div className="LandingPage">
        </div>


    );
}

export default EnterInfo3;