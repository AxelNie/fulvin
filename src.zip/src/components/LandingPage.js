import '../App.css';
import React from "react";
import {Link} from "react-router-dom";
import Button from './Button';


const LandingPage = () => {
  return (
    <div className="LandingPage">
      <div>
        <h1>FULVIN.</h1>
      </div>
      <li className="Button">
            <Link to="/1">Börja brygg</Link>
      </li>
       

    </div>
  );
}

export default LandingPage;
