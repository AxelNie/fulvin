import '../App.css';
import React, {useState} from "react";
import Button from './Button';



const EnterInfo1 = ({onInput}) => {
  const [text, setText] = useState("");


  return (
    <div className="LandingPage">
      <header>
        <h1>ENTERinfo1</h1>
      </header>
      
      <input placeholder="Ange namn" onChange={(e)=>setText(e.target.value)} ></input>
      <Button onClick={()=>onInput(text)}>Nästa steg</Button>

    </div>


  );

}

export default EnterInfo1;