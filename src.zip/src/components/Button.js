import '../App.css';
import React, { Children } from "react";

 const Button = ({onClick,children}) => {
  return (
    <div className="Button" onClick={onClick}>
      {children}
    </div>
  );
}

export default Button;
