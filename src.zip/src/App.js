import React, { useState } from "react";
import LandingPage from './components/LandingPage';
import Button from './components/Button';
import NewBrew from './pages/NewBrew';
import './App.css';
import Home from './pages/Home.js';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  useParams,
  Link,
} from "react-router-dom";


function App() {
  const [brewList, setBrewList] = useState([])
  function onNewBrew(brew){
    setBrewList([...brewList,brew])
  }
  console.log(brewList);

  return (
    <div >
      <Router>
        <Switch>
          <Route path="/NewBrew">
            <NewBrew onNewBrew={onNewBrew}/> 
          </Route>
          <Route path="/Home">
            <Home brewList={brewList}/> 
          </Route>
          <Route path="/">
            <LandingPage />
          </Route>
         
        </Switch> <div class="Footer">
        <Link to="/"><div class="Foot-left">   <p class="Footer_text"> Recept </p> </div></Link>
        <Link to="/Home"><div class="Foot-middle"> <p class="Footer_text"> Hem </p> </div></Link>
    <div class="Foot-right"> <p class="Footer_text"> Handbok </p> </div>
  </div>
      </Router>
  


    </div>



  );
}

export default App;
